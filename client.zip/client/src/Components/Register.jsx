import React from 'react'
import { useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
export default function Register() {
   const navigate = useNavigate()
    const [register,setRegister]= useState({
      uname:'',
      uemail:'',
      upassword:''
  })
  const [profileimage, setProfileimage] = useState(null)
  const [imagepreview, setImagepreview] = useState('')

  const handelchange =(e)=>{
    console.log({...register,[e.target.name]:e.target.value})
  setRegister({...register,[e.target.name]:e.target.value})
}

const handleimagechange = (e) => {
  const file = e.target.files[0]

  if (file) {
    setProfileimage(file)
    setImagepreview(URL.createObjectURL(file))
  }
}

const handelsubmit = async (e)=>{
  e.preventDefault()

  try {
    console.log('register user',register)

    const res = await axios.post('http://localhost:7002/User/adduser',register)

    console.log("response",res.data)

    if (!res.data.success || !res.data.newuser?._id) {
      alert(res.data.message || 'User registration failed')
      return
    }

if (profileimage) {
  const formData = new FormData()
  formData.append('profileimage', profileimage)

  try {
    const imageRes = await axios.put(
      `http://localhost:7002/User/uploadprofileimage/${res.data.newuser._id}`,
      formData
    )

    console.log('Image upload response:', imageRes.data)
    console.log('Saved filename:', imageRes.data.updateprofile?.profileimage)
     alert(res.data.message)
    navigate('/login')
  } catch (error) {
    console.log('Image upload error:', error.response?.data || error.message)
  }
}
  } catch (error) {
    console.log(error)
    alert(error.response?.data?.message || 'Registration failed')
  }
}

  return (
    <div>
      <section className="auth-wrap">
  <div className="container">
    <div className="auth-card">
      <span className="eyebrow">
        Get started
      </span>
      <h2 className="mt-2">
        Create your account
      </h2>
      <p className="small-muted">
        Shop faster and keep your orders in one place.
      </p>

      <div className="text-center mt-3 mb-3">
        <label htmlFor="profileimage" style={{ cursor: 'pointer' }}>
          <img
            src={imagepreview || '/assets/img/profile.png'}
            alt="Profile"
            onError={(e) => {
              e.target.onerror = null
              e.target.src = 'https://placehold.co/100x100?text=User'
            }}
            style={{
              width: '100px',
              height: '100px',
              borderRadius: '50%',
              objectFit: 'cover',
              border: '2px solid #ff5a36'
            }}
          />
        </label>

        <input
          type="file"
          id="profileimage"
          accept="image/*"
          className="d-none"
          onChange={handleimagechange}
        />

        <p className="small-muted mt-2 mb-0">
          Click the image to upload a profile picture
        </p>
      </div>

      <input className="form-control mt-3" placeholder="Full name" name='uname' value={register.uname} onChange={handelchange} />
      <input className="form-control mt-3" placeholder="Email address" type="email" name='uemail' value={register.uemail} onChange={handelchange} />
      <input className="form-control mt-3" placeholder="Create password" type="password" name='upassword' value={register.upassword} onChange={handelchange}/>
      <button className="btn btn-brand w-100 mt-4" onClick={handelsubmit}>
        Create account
      </button>
      <p className="text-center small-muted mt-4 mb-0">
        Already registered?
        <a href="/login">
          Sign in
        </a>
      </p>
    </div>
  </div>
</section>

    </div>
  )
}
