import React from 'react'
import { useState, useEffect } from 'react'
import axios from 'axios'
import { useSearchParams } from 'react-router-dom'

export default function Shop() {
  const [product, setProduct] = useState([])
  const [category, setCategory] = useState([])
  const [selectedcategory, setSelectedcategory] = useState('')
  const [search, setSearch] = useState('')
  const [searchParams, setSearchParams] = useSearchParams()

  const fetchcategory = async () => {
    try {
      const res = await axios.get('http://localhost:7002/category/viewcategory')
      setCategory(res.data.allcategory || [])
    } catch (error) {
      console.log(error)
    }
  }

  const fetchedproduct = async () => {
    try {
      const res = await axios.get('http://localhost:7002/product/viewproduct')
      setProduct(res.data.allproduct || [])
    } catch (error) {
      console.log(error)
    }
  }

  const addToCart = async (productId) => {
    try {
      const token = localStorage.getItem('Usertoken')

      if (!token) {
        alert('Please login to add products to cart')
        return
      }

      const selectedProduct = product.find(
        (pdata) => pdata._id === productId
      )

      if (!selectedProduct || selectedProduct.stock <= 0) {
        alert('This product is out of stock')
        return
      }

      const res = await axios.post(
        'http://localhost:7002/cart/addtocart',
        {
          productId: productId,
          quantity: 1
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      if (res.data.success) {
        alert('Product added to cart')
        window.dispatchEvent(new Event('cartUpdated'))
      }
    } catch (error) {
      alert(
        error.response?.data?.message ||
        'Failed to add product to cart'
      )
    }
  }

  useEffect(() => {
    fetchcategory()
    fetchedproduct()
  }, [])

  useEffect(() => {
    setSelectedcategory(searchParams.get('category') || '')
  }, [searchParams])

  const filteredproduct = product.filter((pdata) => {
    const productcategory =
      typeof pdata.category === 'object'
        ? pdata.category?._id
        : pdata.category

    const categoryname =
      typeof pdata.category === 'object'
        ? pdata.category?.name || pdata.category?.cname
        : category.find(
            (cdata) => String(cdata._id) === String(productcategory)
          )?.name ||
          category.find(
            (cdata) => String(cdata._id) === String(productcategory)
          )?.cname

    const matchescategory =
      selectedcategory === '' ||
      String(productcategory) === String(selectedcategory)

    const searchtext = String(search || '').toLowerCase().trim()

    const matchessearch =
      String(pdata.name || '').toLowerCase().includes(searchtext) ||
      String(categoryname || '').toLowerCase().includes(searchtext)

    return matchescategory && matchessearch
  })

  return (
    <div>
      <div>
        <section className="page-head">
          <div className="container">
            <span className="eyebrow">
              Collection
            </span>
            <h1 className="mt-2">
              {selectedcategory
                ? category.find(
                    (cdata) => String(cdata._id) === String(selectedcategory)
                  )?.name || 'Shop Products'
                : 'Shop all products'}
            </h1>
            <p className="small-muted">
              Find your next favourite piece of tech.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="filter-bar row g-2 mb-4">
              <div className="col-lg-7">
                <input
                  className="form-control"
                  id="search"
                  placeholder="Search products..."
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                />
              </div>

              <div className="col-lg-5">
                <select
                  className="form-select"
                  id="category"
                  value={selectedcategory}
                  onChange={(e) => {
                    const categoryid = e.target.value
                    setSelectedcategory(categoryid)

                    if (categoryid) {
                      setSearchParams({ category: categoryid })
                    } else {
                      setSearchParams({})
                    }
                  }}
                >
                  <option value="">
                    All categories
                  </option>

                  {category.map((cdata) => (
                    <option key={cdata._id} value={cdata._id}>
                      {cdata.name}
                    </option>
                  ))}
                </select>
              </div>
            </div>

            <div className="row g-4" id="shop-grid">
              {filteredproduct.length > 0 ? (
                filteredproduct.map((pdata) => {
                  const productcategory =
                    typeof pdata.category === 'object'
                      ? pdata.category?._id
                      : pdata.category

                  const categoryname =
                    typeof pdata.category === 'object'
                      ? pdata.category?.name || pdata.category?.cname
                      : category.find(
                          (cdata) => String(cdata._id) === String(productcategory)
                        )?.name ||
                        category.find(
                          (cdata) => String(cdata._id) === String(productcategory)
                        )?.cname

                  return (
                    <div
                      className="col-md-6 col-lg-3 shop-product"
                      key={pdata._id}
                    >
                      <div className="product-card overflow-hidden">
                        <a
                          href={`/product/${pdata._id}`}
                          className="product-image-link"
                          aria-label={`View ${pdata.name} details`}
                        >
                          <img
                            className="product-img"
                            src={
                              pdata.image
                                ? `http://localhost:7002/image/${pdata.image}`
                                : '/assets/img/product-1.png'
                            }
                            alt={pdata.name}
                          />
                        </a>

                        <div className="product-body">
                          <div className="d-flex justify-content-between">
                            <span className="small-muted">
                              {categoryname || 'Uncategorized'}
                            </span>
                            <span className="badge badge-sale">New</span>
                          </div>

                          <h5 className="mt-2 mb-2">
                            <a
                              href={`/product/${pdata._id}`}
                              className="product-title-link"
                            >
                              {pdata.name}
                            </a>
                          </h5>

                          <div className="rating mb-2">
  <span style={{ color: '#ffc107' }}>
    {'★'.repeat(
      Math.min(5, Math.max(0, Math.round(Number(pdata.averageRating) || 0)))
    )}
    {'☆'.repeat(
      5 - Math.min(5, Math.max(0, Math.round(Number(pdata.averageRating) || 0)))
    )}
  </span>

  <span className="small-muted ms-2">
    {Number(pdata.averageRating || 0).toFixed(1)}
  </span>

  <span className="small-muted ms-1">
    ({pdata.totalReviews || 0})
  </span>
</div>

                          {/* Stock Status */}
                          <div className="mb-2">
                            {pdata.stock <= 0 ? (
                              <span className="text-danger fw-bold">
                                Out of Stock
                              </span>
                            ) : pdata.stock <= 5 ? (
                              <span className="text-warning fw-bold">
                                Only {pdata.stock} left
                              </span>
                            ) : (
                              <span className="text-success fw-bold">
                                In Stock
                              </span>
                            )}
                          </div>

                          <div className="d-flex align-items-center justify-content-between">
                            <span className="price">
                              ₹{pdata.price}
                            </span>

                            <button
                              type="button"
                              className="icon-btn"
                              title={
                                pdata.stock <= 0
                                  ? 'Out of Stock'
                                  : 'Add to cart'
                              }
                              disabled={pdata.stock <= 0}
                              onClick={() => addToCart(pdata._id)}
                            >
                              +
                            </button>
                          </div>
                        </div>
                      </div>
                    </div>
                  )
                })
              ) : (
                <div className="col-12 text-center">
                  <p className="small-muted">
                    No products found in this category.
                  </p>
                </div>
              )}
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}