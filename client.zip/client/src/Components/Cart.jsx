
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

export default function Cart() {

const [cart,setCart] = useState([])

useEffect(()=>{
const viewcart = async () => {
try {
const token = localStorage.getItem('Usertoken') || localStorage.getItem('Usertoken')

const res = await axios.get('http://localhost:7002/cart/viewcart',{
headers:{
Authorization:`Bearer ${token}`
}
})

setCart(res.data.items || [])

} catch(error) {
console.log(error)
}
}

viewcart()
},[])

const updatequantity = async (id,quantity) => {
try {

const token = localStorage.getItem('Usertoken') || localStorage.getItem('usertoken')

if(quantity <= 0){
removecart(id)
return
}

await axios.put(`http://localhost:7002/cart/updatecart/${id}`,{
quantity: quantity
},{
headers:{
Authorization:`Bearer ${token}`
}
})

const updatedcart = cart.map((item)=>{
if(item.product?._id === id){
return {...item,quantity: quantity}
}
return item
})

setCart(updatedcart)

} catch(error) {
console.log(error)
}
}

const removecart = async (id) => {
try {

const token = localStorage.getItem('Usertoken') || localStorage.getItem('usertoken')

await axios.delete(`http://localhost:7002/cart/removecart/${id}`,{
headers:{
Authorization:`Bearer ${token}`
}
})

const updatedcart = cart.filter((item)=>item.product?._id !== id)

setCart(updatedcart)

} catch(error) {
console.log(error)
}
}

const subtotal = cart.reduce((total,item)=>{
return total + Number(item.product?.price || 0) * Number(item.quantity || 1)
},0)

return (
<div>

    <div>
  <section className="page-head">
    <div className="container">
      <span className="eyebrow">
        Your order
      </span>
      <h1 className="mt-2">
        Shopping cart
      </h1>
    </div>
  </section>
  <section className="section">
    <div className="container">
      <div className="row g-5">
        <div className="col-lg-8">
       <div id="cart-items">

 <div className="row align-items-center border-bottom pb-3 mb-3">
  <div className="col-md-5">
   <b>
    Product
   </b>
  </div>

  <div className="col-md-2 text-center">
   <b>
    Price
   </b>
  </div>

  <div className="col-md-2 text-center">
   <b>
    Quantity
   </b>
  </div>

  <div className="col-md-2 text-center">
   <b>
    Subtotal
   </b>
  </div>

  <div className="col-md-1">
  </div>
 </div>

</div>

{cart.map((item,index)=>(
<div key={item.product?._id || index} className="row align-items-center border-bottom py-3">

    <div className="col-md-5">
        <div className="d-flex align-items-center gap-3">
            <img src={item.product?.image ? (Array.isArray(item.product.image) ? `http://localhost:7002/image/${item.product.image[0]}` : item.product.image.startsWith('http') ? item.product.image : `http://localhost:7002/image/${item.product.image}`) : '../assets/img/product-1.png'}
                 width="70"
                 height="70"
                 className="rounded"
                 alt={item.product?.name || 'Product'}/>

            <div>
                <h6 className="mb-1">{item.product?.name}</h6>
                <small className="text-muted">{item.product?.category?.name || 'Product'}</small>
            </div>
        </div>
    </div>

    <div className="col-md-2 text-center">
        ₹{Number(item.product?.price || 0).toLocaleString('en-IN')}
    </div>

    <div className="col-md-2 text-center">
        <div className="d-flex justify-content-center align-items-center">
            <button className="btn btn-sm btn-outline-secondary" onClick={()=>updatequantity(item.product?._id,Number(item.quantity || 1)-1)}>−</button>
            <span className="mx-3">{item.quantity || 1}</span>
            <button className="btn btn-sm btn-outline-secondary" onClick={()=>updatequantity(item.product?._id,Number(item.quantity || 1)+1)}>+</button>
        </div>
    </div>

    <div className="col-md-2 text-center fw-bold">
        ₹{(Number(item.product?.price || 0) * Number(item.quantity || 1)).toLocaleString('en-IN')}
    </div>

    <div className="col-md-1 text-center">
        <button className="btn btn-sm btn-danger" onClick={()=>removecart(item.product?._id)}>
            Remove
        </button>
    </div>

</div>
))}

{cart.length === 0 && (
<div className="text-center py-4">
<p>Your cart is empty.</p>
<Link className="btn btn-brand" to="/shop">Continue shopping</Link>
</div>
)}

        </div>
        <div className="col-lg-4">
          <div className="info-card p-4 sticky-top" style={{top: 110}}>
            <h4>
              Order summary
            </h4>
            <div className="d-flex justify-content-between mt-4">
              <span>
                Subtotal
              </span>
              <b className="cart-total">
                ₹{subtotal.toLocaleString('en-IN')}
              </b>
            </div>
            <div className="d-flex justify-content-between mt-2">
              <span>
                Delivery
              </span>
              <span className="text-success">
                Free
              </span>
            </div>
            <hr />
            <div className="d-flex justify-content-between">
              <b>
                Total
              </b>
              <b className="cart-total">
                ₹{subtotal.toLocaleString('en-IN')}
              </b>
            </div>
            <Link className="btn btn-brand w-100 mt-4" to="/checkout">
              Proceed to checkout
            </Link>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>

</div>
)
}
