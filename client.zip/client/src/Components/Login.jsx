import React, { useState } from 'react'
import { host } from '../Context/Host.jsx'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'
export default function Login() {
  const navigate = useNavigate()
  const [login, setLogin] = useState({
    uemail: "",
    upassword: ""
  })
  const handelchange = (e) => {
    console.log({ ...login, [e.target.name]: e.target.value })
    setLogin({ ...login, [e.target.name]: e.target.value })
  }

 
const handelsubmit = async (e) => {
  e.preventDefault()

  try {
    const res = await axios.post(`${host}/User/login`, login)

    console.log('Login response:', res.data)

    const token = res.data.token

    if (!token) {
      alert('Login response does not contain a token. Check the backend response.')
      return
    }

    localStorage.setItem('Usertoken', token)

    alert(res.data.message || 'Login successful')

    navigate('/')
  } catch (error) {
    console.error(
      'Login error:',
      error.response?.data || error.message
    )

    alert(
      error.response?.data?.message ||
      'Invalid email or password'
    )
  }
}

  return (
    <div>
      <section className="auth-wrap">
        <div className="container">
          <div className="auth-card">
            <span className="eyebrow">
              Welcome back
            </span>
            <h2 className="mt-2">
              Sign in to nova cart
            </h2>
            <p className="small-muted">
              Access your orders and wishlist.
            </p>
            <label className="form-label mt-3">
              Email
            </label>
            <input className="form-control mb-3" placeholder="you@example.com" type="email" name='uemail' onChange={handelchange} />
            <label className="form-label">
              Password
            </label>
            <input className="form-control" placeholder="••••••••" type="password" name='upassword' onChange={handelchange} />
            <button className="btn btn-brand w-100 mt-4" onClick={handelsubmit}>
              Sign in
            </button>
            <p className="text-center small-muted mt-4 mb-0">
              New here?
              <a href="/register">
                Create an account
              </a>
            </p>
          </div>
        </div>
      </section>

    </div>
  )
}
