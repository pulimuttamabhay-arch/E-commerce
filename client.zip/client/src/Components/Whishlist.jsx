
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

export default function Wishlist() {
  const [wishlist, setWishlist] = useState(
    () => JSON.parse(localStorage.getItem('wishlist')) || []
  )

  const [product, setProduct] = useState([])
  const [loading, setLoading] = useState(true)

  const fetchproduct = () => {
    axios.get('http://localhost:7002/product/viewproduct')
      .then((res) => {
        setProduct(res.data.allproduct || [])
      })
      .catch((error) => {
        console.log(error)
      })
      .finally(() => {
        setLoading(false)
      })
  }

  useEffect(() => {
    fetchproduct()
  }, [])

  useEffect(() => {
    const updateWishlist = () => {
      setWishlist(JSON.parse(localStorage.getItem('wishlist')) || [])
    }

    window.addEventListener('wishlistUpdated', updateWishlist)
    window.addEventListener('storage', updateWishlist)

    return () => {
      window.removeEventListener('wishlistUpdated', updateWishlist)
      window.removeEventListener('storage', updateWishlist)
    }
  }, [])

  const removeWishlist = (productId) => {
    const newWishlist = wishlist.filter(
      (id) => id !== productId
    )

    localStorage.setItem('wishlist', JSON.stringify(newWishlist))
    setWishlist(newWishlist)

    window.dispatchEvent(new Event('wishlistUpdated'))
  }

  const addToCart = async (productId) => {
    try {
      const token = localStorage.getItem('Usertoken')

      if (!token) {
        alert('Please login to add products to cart')
        return
      }

      const selectedProduct = product.find(
        (pdata) => pdata._id === productId
      )

      if (!selectedProduct || selectedProduct.stock <= 0) {
        alert('This product is out of stock')
        return
      }

      const res = await axios.post(
        'http://localhost:7002/cart/addtocart',
        {
          productId: productId,
          quantity: 1
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      if (res.data.success) {
        alert('Product added to cart')
        window.dispatchEvent(new Event('cartUpdated'))
      } else {
        alert(res.data.message || 'Failed to add product to cart')
      }

    } catch (error) {
      alert(
        error.response?.data?.message ||
        'Failed to add product to cart'
      )
    }
  }

  const wishlistproduct = product.filter(
    (pdata) => wishlist.includes(pdata._id)
  )

  return (
    <div className="container py-5">
      <div className="d-flex justify-content-between align-items-center mb-4">
        <div>
          <h2>My Wishlist ♡</h2>
          <p className="text-muted">
            Your favourite products in one place
          </p>
        </div>

        <Link to="/shop" className="btn btn-outline-dark">
          Continue Shopping
        </Link>
      </div>

      {loading ? (
        <div className="text-center py-5">
          <p>Loading your wishlist...</p>
        </div>
      ) : wishlistproduct.length === 0 ? (
        <div className="text-center py-5">
          <h4>Your wishlist is empty</h4>

          <p className="text-muted">
            Add your favourite products by clicking the heart icon.
          </p>

          <Link to="/shop" className="btn btn-dark mt-2">
            Explore Products
          </Link>
        </div>
      ) : (
        <div className="row g-4">
          {wishlistproduct.map((pdata) => (
            <div className="col-6 col-md-4 col-lg-3" key={pdata._id}>
              <div className="card h-100 border-0 shadow-sm p-3">
                <div className="d-flex justify-content-end">
                  <button
                    type="button"
                    className="btn btn-light text-danger"
                    title="Remove from wishlist"
                    onClick={() => removeWishlist(pdata._id)}
                  >
                    ♥ Remove
                  </button>
                </div>

                <Link
                  to={`/product/${pdata._id}`}
                  className="text-decoration-none text-dark"
                >
                  <img
                    src={
                      pdata.image && pdata.image.length > 0
                        ? pdata.image[0]
                        : '/assets/img/product-1.png'
                    }
                    alt={pdata.name}
                    className="img-fluid mb-3"
                    style={{
                      height: '180px',
                      width: '100%',
                      objectFit: 'contain'
                    }}
                  />

                  <h5>{pdata.name}</h5>

                  <h6 className="fw-bold">₹{pdata.price}</h6>
                </Link>

                <p
                  className={
                    pdata.stock <= 0
                      ? 'text-danger'
                      : 'text-success'
                  }
                >
                  {pdata.stock <= 0 ? 'Out of Stock' : 'In Stock'}
                </p>

                <button
                  type="button"
                  className="btn btn-dark w-100 mt-auto"
                  onClick={() => addToCart(pdata._id)}
                  disabled={pdata.stock <= 0}
                >
                  {pdata.stock <= 0 ? 'Out of Stock' : 'Add to Cart'}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
