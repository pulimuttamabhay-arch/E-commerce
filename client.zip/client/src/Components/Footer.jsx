 import React from 'react'
 
 export default function Footer() {
   return (
     <div>
        <footer className="footer mt-5">
    <div className="container">
      <div className="row g-4">
        <div className="col-lg-4">
          <h3 className="text-white">
            Nova
            <span style={{color: '#ff5a36'}}>
              Cart
            </span>
          </h3>
          <p>
            Modern shopping for electronics, gadgets and everyday tech essentials.
          </p>
        </div>
        <div className="col-6 col-lg-2">
          <h5>
            Shop
          </h5>
          <a className="d-block mb-2" href="shop.html">
            All products
          </a>
          <a className="d-block mb-2" href="categories.html">
            Categories
          </a>
          <a className="d-block" href="cart.html">
            Cart
          </a>
        </div>
        <div className="col-6 col-lg-2">
          <h5>
            Company
          </h5>
          <a className="d-block mb-2" href="about.html">
            About us
          </a>
          <a className="d-block" href="contact.html">
            Contact
          </a>
        </div>
        <div className="col-lg-4">
          <div className="newsletter">
            <h5>
              Get product updates
            </h5>
            <p className="small-muted">
              New launches, offers and useful tech picks.
            </p>
            <div className="input-group">
              <input className="form-control" placeholder="Email address" />
              <button className="btn btn-brand">
                Join
              </button>
            </div>
          </div>
        </div>
      </div>
      <hr className="border-secondary my-5" />
      <div className="d-flex justify-content-between small">
        <span>
          © 2026 NovaCart
        </span>
        <span>
          Built as a clean Bootstrap ecommerce template
        </span>
      </div>
    </div>
  </footer>
     </div>
   )
 }
 