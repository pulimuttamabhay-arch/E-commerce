
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { useNavigate } from 'react-router-dom'

const loadRazorpay = () => {
  return new Promise((resolve) => {

    if (window.Razorpay) {
      resolve(true)
      return
    }

    const script = document.createElement('script')

    script.src = 'https://checkout.razorpay.com/v1/checkout.js'

    script.onload = () => resolve(true)
    script.onerror = () => resolve(false)

    document.body.appendChild(script)
  })
}

export default function Checkout() {

  const navigate = useNavigate()

  const [shipping, setShipping] = useState({
    fname: '',
    lname: '',
    address: '',
    city: '',
    pincode: '',
    phone: ''
  })

  const [payment, setPayment] = useState('Cash on delivery')
  const [cart, setCart] = useState([])
  const [loading, setLoading] = useState(false)

  useEffect(() => {

    const getcart = async () => {

      try {

        const token = localStorage.getItem('Usertoken')

        if (!token) {
          alert('Please login first')
          navigate('/login')
          return
        }

        const res = await axios.get(
          'http://localhost:7002/cart/viewcart',
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        )

        console.log('Checkout cart:', res.data)

        setCart(res.data.items || [])

      } catch (error) {

        console.log(
          'Checkout cart error:',
          error.response?.data || error.message
        )

      }
    }

    getcart()

  }, [navigate])

  const totalAmount = cart.reduce((total, item) => {

    const price = Number(item.product?.price || item.price || 0)
    const quantity = Number(item.quantity || 1)

    return total + price * quantity

  }, 0)

  const deliveryCharge =
    totalAmount >= 599 || totalAmount === 0 ? 0 : 50

  const grandTotal = totalAmount + deliveryCharge

  const handlechange = (e) => {

    const { name, value } = e.target

    if (name === 'phone') {

      const phone = value.replace(/\D/g, '').slice(0, 10)

      setShipping({
        ...shipping,
        phone
      })

      return
    }

    if (name === 'pincode') {

      const pincode = value.replace(/\D/g, '').slice(0, 6)

      setShipping({
        ...shipping,
        pincode
      })

      return
    }

    setShipping({
      ...shipping,
      [name]: value
    })

  }

  const placeorder = async () => {

    if (loading) return

    if (
      !shipping.fname.trim() ||
      !shipping.lname.trim() ||
      !shipping.address.trim() ||
      !shipping.city.trim() ||
      !shipping.pincode.trim() ||
      !shipping.phone.trim()
    ) {

      alert('Please fill all shipping details')
      return

    }

    if (!/^\d{6}$/.test(shipping.pincode.trim())) {

      alert('Please enter a valid 6-digit PIN code')
      return

    }

    const phone = shipping.phone.trim()

    if (!/^[6-9]\d{9}$/.test(phone)) {

      alert('Please enter a valid 10-digit Indian mobile number')
      return

    }

    if (cart.length === 0) {

      alert('Your cart is empty')
      return

    }

    const token = localStorage.getItem('Usertoken')

    if (!token) {

      alert('Please login first')
      navigate('/login')
      return

    }

    const shippingAddress =
      `${shipping.fname} ${shipping.lname}, ${shipping.address}, ${shipping.city}, ${shipping.pincode}, Phone: ${phone}`

    setLoading(true)

    try {

      // CASH ON DELIVERY

      if (payment === 'Cash on delivery') {

        const res = await axios.post(
          'http://localhost:7002/payment/demo-checkout',
          {
            shippingAddress,
            paymentMethod: 'COD'
          },
          {
            headers: {
              Authorization: `Bearer ${token}`
            }
          }
        )

        if (res.data.success) {

          setCart([])

          alert('COD order placed successfully')

          navigate('/myorders', {
            replace: true,
            state: {
              order: res.data.order,
              payment: res.data.payment
            }
          })

        } else {

          alert(res.data.message || 'Error placing order')

        }

        return
      }

      // LOAD RAZORPAY SCRIPT

      const loaded = await loadRazorpay()

      if (!loaded) {

        alert('Razorpay SDK failed to load. Check your internet connection.')
        return

      }

      // CREATE RAZORPAY ORDER

      const orderResponse = await axios.post(
        'http://localhost:7002/payment/create-razorpay-order',
        {
          shippingAddress,
          paymentMethod: payment,
          phone: phone
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      if (!orderResponse.data.success) {

        alert(
          orderResponse.data.message ||
          'Unable to create payment order'
        )

        return

      }

      const razorpayOrder = orderResponse.data

      // RAZORPAY OPTIONS

      console.log('Entered phone:', phone)
      console.log('Phone length:', phone.length)
      console.log('Razorpay contact:', `+91${phone}`)

      const options = {

        key: razorpayOrder.keyId,

        amount: razorpayOrder.amount,

        currency: razorpayOrder.currency,

        name: 'QuickSell',

        description: 'Order Payment',

        order_id: razorpayOrder.razorpayOrderId,

        prefill: {

          name: `${shipping.fname} ${shipping.lname}`

        },

        handler: async function (response) {

          try {

            // VERIFY PAYMENT

            const verifyResponse = await axios.post(
              'http://localhost:7002/payment/verify-razorpay-payment',
              {
                razorpay_order_id: response.razorpay_order_id,
                razorpay_payment_id: response.razorpay_payment_id,
                razorpay_signature: response.razorpay_signature
              },
              {
                headers: {
                  Authorization: `Bearer ${token}`
                }
              }
            )

            if (verifyResponse.data.success) {

              setCart([])

              alert('Payment successful! Your order has been placed.')

              navigate('/myorders', {
                replace: true,
                state: {
                  order: verifyResponse.data.order,
                  payment: verifyResponse.data.payment
                }
              })

            } else {

              alert(
                verifyResponse.data.message ||
                'Payment verification failed'
              )

            }

          } catch (error) {

            console.log(
              'Payment verification error:',
              error.response?.data || error.message
            )

            alert(
              error.response?.data?.message ||
              'Payment verification failed. Please contact support before retrying.'
            )

          }

        },

        modal: {

          ondismiss: function () {

            alert('Payment cancelled. You can try again.')

          }

        },

        theme: {
          color: '#ff5a36'
        }

      }

      const razorpay = new window.Razorpay(options)

      razorpay.on('payment.failed', function (response) {

        console.log('Razorpay payment failed:', response.error)

        alert(
          response.error.description ||
          'Payment failed. Please try again.'
        )

      })

      razorpay.open()

    } catch (error) {

      console.log(
        'Place order error:',
        error.response?.data || error.message
      )

      alert(
        error.response?.data?.message ||
        'Error placing order'
      )

    } finally {

      setLoading(false)

    }

  }

  return (

    <div>

      <section className="page-head">
        <div className="container">

          <span className="eyebrow">
            Secure checkout
          </span>

          <h1 className="mt-2">
            Complete your order
          </h1>

        </div>
      </section>

      <section className="section">
        <div className="container">

          <div className="row g-5">

            <div className="col-lg-7">

              <div className="info-card p-4 p-lg-5">

                <h4>
                  Shipping details
                </h4>

                <div className="row g-3 mt-1">

                  <div className="col-md-6">

                    <label className="form-label">
                      First name
                    </label>

                    <input
                      type="text"
                      className="form-control"
                      name="fname"
                      value={shipping.fname}
                      onChange={handlechange}
                    />

                  </div>

                  <div className="col-md-6">

                    <label className="form-label">
                      Last name
                    </label>

                    <input
                      type="text"
                      className="form-control"
                      name="lname"
                      value={shipping.lname}
                      onChange={handlechange}
                    />

                  </div>

                  <div className="col-12">

                    <label className="form-label">
                      Address
                    </label>

                    <input
                      type="text"
                      className="form-control"
                      name="address"
                      value={shipping.address}
                      onChange={handlechange}
                    />

                  </div>

                  <div className="col-md-6">

                    <label className="form-label">
                      City
                    </label>

                    <input
                      type="text"
                      className="form-control"
                      name="city"
                      value={shipping.city}
                      onChange={handlechange}
                    />

                  </div>

                  <div className="col-md-6">

                    <label className="form-label">
                      PIN code
                    </label>

                    <input
                      type="text"
                      className="form-control"
                      name="pincode"
                      value={shipping.pincode}
                      onChange={handlechange}
                      placeholder="6-digit PIN code"
                      maxLength="6"
                    />

                  </div>

                  <div className="col-12">

                    <label className="form-label">
                      Mobile number
                    </label>

                    <div className="input-group">

                      <span className="input-group-text">
                        +91
                      </span>

                      <input
                        type="tel"
                        className="form-control"
                        name="phone"
                        value={shipping.phone}
                        maxLength={10}
                        onChange={handlechange}
                        placeholder="Enter 10 digit mobile number"
                        required
                      />

                    </div>

                    <small className="text-muted">
                      Enter your 10-digit Indian mobile number.
                    </small>

                  </div>

                  <div className="col-12">

                    <div className="mb-4">

                      <h4 className="mb-3">
                        Payment Method
                      </h4>

                      <select
                        className="form-select mb-3"
                        value={payment}
                        onChange={(e) => setPayment(e.target.value)}
                        disabled={loading}
                      >

                        <option value="Cash on delivery">
                          Cash on Delivery
                        </option>

                        <option value="UPI">
                          UPI
                        </option>

                        <option value="Card">
                          Credit / Debit Card
                        </option>

                        <option value="NetBanking">
                          Net Banking
                        </option>

                      </select>

                      {payment === 'Cash on delivery' && (

                        <div className="alert alert-info">
                          You can pay when your order is delivered.
                        </div>

                      )}

                      {payment === 'UPI' && (

                        <div className="border rounded p-3">

                          <h5>Pay using UPI</h5>

                          <p className="text-muted mb-0">
                            Complete your payment securely through Razorpay.
                          </p>

                        </div>

                      )}

                      {payment === 'Card' && (

                        <div className="border rounded p-3">

                          <h5>Credit / Debit Card</h5>

                          <p className="text-muted mb-0">
                            Complete your card payment securely through Razorpay.
                          </p>

                        </div>

                      )}

                      {payment === 'NetBanking' && (

                        <div className="border rounded p-3">

                          <h5>Net Banking</h5>

                          <p className="text-muted mb-0">
                            Complete your payment securely through Razorpay.
                          </p>

                        </div>

                      )}

                    </div>

                  </div>

                  <div className="col-12">

                    <button
                      className="btn btn-brand w-100 mt-3"
                      onClick={placeorder}
                      disabled={loading}
                    >

                      {loading
                        ? 'Processing...'
                        : payment === 'Cash on delivery'
                          ? 'Place order'
                          : 'Pay now'}

                    </button>

                  </div>

                </div>

              </div>

            </div>

            <div className="col-lg-5">

              <div className="info-card p-4">

                <h4>
                  Order total
                </h4>

                <p className="small-muted">
                  Your cart total
                </p>

                <div className="d-flex justify-content-between">

                  <span>Subtotal</span>

                  <span>
                    ₹{totalAmount.toLocaleString('en-IN')}
                  </span>

                </div>

                <div className="d-flex justify-content-between mt-2">

                  <span>Delivery</span>

                  <span>
                    {deliveryCharge === 0
                      ? 'Free'
                      : `₹${deliveryCharge.toLocaleString('en-IN')}`}
                  </span>

                </div>

                <hr />

                <div className="d-flex justify-content-between">

                  <b>Grand Total</b>

                  <h2 className="cart-total">
                    ₹{grandTotal.toLocaleString('en-IN')}
                  </h2>

                </div>

                <hr />

                {cart.map((item, index) => {

                  const product = item.product || item

                  return (

                    <div
                      key={product._id || index}
                      className="d-flex justify-content-between mb-2"
                    >

                      <span>
                        {product.name || item.productName} × {item.quantity || 1}
                      </span>

                      <span>
                        ₹{(
                          Number(product.price || item.price || 0) *
                          Number(item.quantity || 1)
                        ).toLocaleString('en-IN')}
                      </span>

                    </div>

                  )

                })}

                {cart.length === 0 && (

                  <p className="small-muted">
                    Your cart is empty.
                  </p>

                )}

                <hr />

                <p className="small-muted mb-0">
                  Secure online payments powered by Razorpay Test Mode.
                </p>

              </div>

            </div>

          </div>

        </div>
      </section>

    </div>

  )

}
