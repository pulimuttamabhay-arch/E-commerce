import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'
export default function Category() {
  const [category,setCategory]=useState([])
  const fetchcategory = async(req,res)=>{
    axios.get('http://localhost:7002/category/viewcategory')
    .then((res)=>{
      console.log(res)
      setCategory(res.data.allcategory)
    })
    .catch((error)=>{
      console.log(error)
    })
  } 
  useEffect(()=>{
    fetchcategory()
  },[])
  return (
    <div>
      <div>
        <section className="page-head">
          <div className="container">
            <span className="eyebrow">
              Explore
            </span>
            <h1 className="mt-2">
              Categories
            </h1>
            <p className="small-muted">
              Everything organised into simple collections.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="row g-4">
              {category.map((cat)=>(
                <div className="col-md-6 col-lg-4" key={cat._id}>
                  <div className="info-card p-4">
                    <div className="feature-icon">
                      <img
                        className="product-img"
                        src={
                          cat.image
                            ? `http://localhost:7002/image/${cat.image}`
                            : '/assets/img/product-1.png'
                        }
                        alt={cat.name}
                        onError={(e)=>{
                          e.target.onerror = null
                          e.target.src = '/assets/img/product-1.png'
                        }}
                        style={{
                          width:'500%',
                          height:'100px',
                          objectFit:'cover',
                          borderRadius:'10px'
                        }}
                      />
                    </div>
                    <h4 className="mt-4">
                      {cat.name}
                    </h4>
                    <p className="small-muted">
                      {cat.description}
                    </p>
                    <Link className="fw-bold text-dark" to={`/shop?category=${cat._id}`}>
                      Browse {cat.name} →
                    </Link>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </section>
      </div>
    </div>
  )
}