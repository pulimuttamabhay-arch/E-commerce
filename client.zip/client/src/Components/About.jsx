import React from 'react'
export default function About() {
  return (
    <div>
      <div>
  <section className="page-head">
    <div className="container">
      <span className="eyebrow">
        Our story
      </span>
      <h1 className="mt-2">
        Shopping, made simpler.
      </h1>
      <p className="small-muted">
        A fresh ecommerce concept inspired by modern electronics storefronts.
      </p>
    </div>
  </section>
  <section className="section">
    <div className="container">
      <div className="row align-items-center g-5">
        <div className="col-lg-6">
          <img alt="Carousel 1" className="hero-img" src="assets/img/carousel-1.jpg" />
        </div>
        <div className="col-lg-6">
          <span className="eyebrow">
            Why NovaCart
          </span>
          <h2 className="section-title mt-2">
            Less noise. Better products.
          </h2>
          <p className="small-muted fs-5">
            NovaCart is designed around discovery, clarity and trust. Products are grouped logically, product information is easy to scan, and checkout is intentionally simple.
          </p>
          <div className="row g-4 mt-2">
            <div className="col-6">
              <h4>
                01
              </h4>
              <p className="small-muted">
                Curated selection
              </p>
            </div>
            <div className="col-6">
              <h4>
                02
              </h4>
              <p className="small-muted">
                Transparent pricing
              </p>
            </div>
            <div className="col-6">
              <h4>
                03
              </h4>
              <p className="small-muted">
                Simple returns
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
</div>
    </div>
  )
}