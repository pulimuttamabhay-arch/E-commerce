import React, { useEffect, useState } from 'react'
import axios from 'axios'
import { Link } from 'react-router-dom'

export default function MyOrders() {
  const [orders, setOrders] = useState([])
  const [loading, setLoading] = useState(true)
  const [reviewTarget, setReviewTarget] = useState(null)
  const [rating, setRating] = useState(5)
  const [reviewText, setReviewText] = useState('')
  const [reviewLoading, setReviewLoading] = useState(false)

  const fetchorders = async () => {
    try {
      const token = localStorage.getItem('Usertoken')

      if (!token) {
        alert('Please login first')
        return
      }

      const res = await axios.get(
        'http://localhost:7002/order/myorders',
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      setOrders(res.data.myorder || [])
    } catch (error) {
      console.log(
        'Fetch orders error:',
        error.response?.data || error.message
      )
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchorders()
  }, [])

  const handleAddReview = async (e) => {
    e.preventDefault()

    try {
      const token = localStorage.getItem('Usertoken')

      if (!token) {
        alert('Please login first')
        return
      }

      if (!reviewTarget) {
        alert('Please select a product to review')
        return
      }

      if (!reviewText.trim()) {
        alert('Please write your review')
        return
      }

      setReviewLoading(true)

      const res = await axios.post(
        'http://localhost:7002/review/addreview',
        {
          productId: reviewTarget.productId,
          orderId: reviewTarget.orderId,
          rating: Number(rating),
          comment: reviewText.trim()
        },
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      alert(res.data.message || 'Review submitted successfully')

      setReviewTarget(null)
      setRating(5)
      setReviewText('')

    } catch (error) {
      console.log(
        'Review submit error:',
        error.response?.data || error
      )

      alert(
        error.response?.data?.message ||
        'Unable to submit review'
      )
    } finally {
      setReviewLoading(false)
    }
  }

  const getstatusclass = (status) => {
    if (status === 'Delivered') return 'order-status delivered'
    if (status === 'Cancelled' || status === 'Returned') return 'order-status cancelled'
    if (status === 'Shipped' || status === 'Out for Delivery') return 'order-status shipped'
    if (status === 'Confirmed' || status === 'Packed') return 'order-status confirmed'
    return 'order-status placed'
  }

  const steps = [
    'Placed',
    'Confirmed',
    'Packed',
    'Shipped',
    'Out for Delivery',
    'Delivered'
  ]

  const getprogress = (status) => {
    if (status === 'Cancelled' || status === 'Returned') return -1
    return steps.indexOf(status)
  }

  return (
    <div className="my-orders-page">
      <style>{`
        .my-orders-page {
          min-height: 100vh;
          background: #f6f8fc;
          padding-bottom: 60px;
          color: #182230;
        }

        .orders-hero {
          background: linear-gradient(125deg, #172554, #2349a4);
          color: white;
          padding: 48px 0 70px;
        }

        .orders-hero p {
          color: #dbeafe;
        }

        .orders-count {
          display: inline-flex;
          align-items: center;
          gap: 8px;
          padding: 9px 15px;
          border: 1px solid #ffffff40;
          background: #ffffff15;
          border-radius: 30px;
          font-size: 14px;
        }

        .orders-content {
          margin-top: -32px;
        }

        .order-card {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 18px;
          overflow: hidden;
          box-shadow: 0 6px 24px #17255408;
          transition: transform .2s, box-shadow .2s;
        }

        .order-card:hover {
          transform: translateY(-2px);
          box-shadow: 0 12px 30px #17255412;
        }

        .order-card-header {
          padding: 22px 24px;
          background: #fcfdff;
          border-bottom: 1px solid #edf0f5;
        }

        .order-label {
          color: #778196;
          font-size: 12px;
          text-transform: uppercase;
          letter-spacing: 1px;
          font-weight: 700;
        }

        .order-id {
          font-weight: 750;
          font-size: 18px;
          margin-top: 5px;
        }

        .order-status {
          display: inline-flex;
          align-items: center;
          gap: 7px;
          padding: 8px 12px;
          border-radius: 30px;
          font-size: 12px;
          font-weight: 700;
          white-space: nowrap;
        }

        .order-status:before {
          content: '';
          height: 7px;
          width: 7px;
          border-radius: 50%;
          background: currentColor;
        }

        .delivered {
          color: #16803d;
          background: #e8f8ee;
        }

        .cancelled {
          color: #c52c36;
          background: #fff0f0;
        }

        .shipped {
          color: #1767c0;
          background: #eaf3ff;
        }

        .confirmed {
          color: #8054c7;
          background: #f2ecff;
        }

        .placed {
          color: #a46508;
          background: #fff5dd;
        }

        .order-card-body {
          padding: 24px;
        }

        .order-product {
          display: flex;
          align-items: center;
          justify-content: space-between;
          gap: 16px;
          padding: 12px 0;
        }

        .product-name {
          font-weight: 650;
          font-size: 14px;
        }

        .product-meta {
          color: #7b8495;
          font-size: 13px;
          margin-top: 5px;
        }

        .product-price {
          font-weight: 700;
          white-space: nowrap;
        }

        .order-progress {
          display: flex;
          align-items: flex-start;
          margin: 28px 0 8px;
        }

        .progress-step {
          flex: 1;
          position: relative;
          text-align: center;
          min-width: 0;
        }

        .progress-step:not(:last-child):after {
          content: '';
          position: absolute;
          top: 12px;
          left: calc(50% + 14px);
          width: calc(100% - 28px);
          height: 3px;
          background: #e5e9f1;
        }

        .progress-step.complete:not(:last-child):after {
          background: #2563eb;
        }

        .progress-dot {
          width: 25px;
          height: 25px;
          border-radius: 50%;
          display: flex;
          align-items: center;
          justify-content: center;
          margin: 0 auto 10px;
          background: #e8edf5;
          color: #7c8799;
          font-size: 12px;
          font-weight: 800;
          position: relative;
          z-index: 1;
        }

        .progress-step.complete .progress-dot {
          color: white;
          background: #2563eb;
        }

        .progress-label {
          color: #8b95a6;
          font-size: 10px;
          line-height: 1.4;
          overflow-wrap: anywhere;
        }

        .progress-step.complete .progress-label {
          color: #24324b;
          font-weight: 650;
        }

        .order-total-box {
          background: #f7f9fd;
          border-radius: 12px;
          padding: 17px 18px;
        }

        .order-total {
          color: #1d4ed8;
          font-size: 23px;
          font-weight: 800;
        }

        .empty-orders {
          background: white;
          border: 1px solid #e7ebf2;
          border-radius: 20px;
          padding: 55px 20px;
          text-align: center;
        }

        .empty-icon {
          width: 76px;
          height: 76px;
          margin: 0 auto 20px;
          display: flex;
          justify-content: center;
          align-items: center;
          background: #edf3ff;
          color: #2456c7;
          border-radius: 24px;
          font-size: 34px;
        }

        .review-form {
          background: #f8faff;
          border: 1px solid #e4eaf5;
          border-radius: 14px;
          padding: 20px;
          margin-top: 12px;
        }

        .review-star {
          font-size: 30px;
          line-height: 1;
          border: none;
          background: transparent;
          padding: 0;
        }

        @media (max-width: 575px) {
          .orders-hero {
            padding: 35px 0 55px;
          }

          .order-card-header,
          .order-card-body {
            padding: 17px;
          }

          .progress-label {
            font-size: 9px;
          }

          .order-total {
            font-size: 20px;
          }

          .order-product {
            flex-wrap: wrap;
          }
        }
      `}</style>

      <section className="orders-hero">
        <div className="container">
          <span className="small text-uppercase fw-bold">
            QUICKSELL · YOUR ACCOUNT
          </span>

          <h1 className="fw-bold mt-3 mb-2">
            My Orders
          </h1>

          <p className="mb-3">
            Track your purchases and stay updated on every delivery.
          </p>

          <span className="orders-count">
            <span>▤</span>
            {orders.length} {orders.length === 1 ? 'Order' : 'Orders'}
          </span>
        </div>
      </section>

      <section className="container orders-content">
        {loading ? (
          <div className="text-center py-5">
            <div className="spinner-border text-primary" role="status" />
            <p className="text-muted mt-3">Loading your orders...</p>
          </div>
        ) : orders.length === 0 ? (
          <div className="empty-orders">
            <div className="empty-icon">🛍️</div>
            <h4 className="fw-bold">No orders yet</h4>
            <p className="text-muted mb-4">
              Your next great find is waiting for you.
            </p>
            <Link to="/shop" className="btn btn-primary px-4 py-2">
              Explore products
            </Link>
          </div>
        ) : (
          <div className="row g-4">
            {orders.map((order) => {
              const progress = getprogress(order.orderStatus)

              return (
                <div className="col-12" key={order._id}>
                  <article className="order-card">
                    <div className="order-card-header">
                      <div className="d-flex justify-content-between align-items-center flex-wrap gap-3">
                        <div>
                          <div className="order-label">Order reference</div>
                          <div className="order-id">
                            #{order._id.slice(-6).toUpperCase()}
                          </div>
                          <div className="text-muted small mt-1">
                            Placed on{' '}
                            {new Date(order.createdAt).toLocaleDateString(
                              'en-IN',
                              {
                                day: 'numeric',
                                month: 'short',
                                year: 'numeric'
                              }
                            )}
                          </div>
                        </div>

                        <span className={getstatusclass(order.orderStatus)}>
                          {order.orderStatus}
                        </span>
                      </div>
                    </div>

                    <div className="order-card-body">
                      <div className="d-flex justify-content-between align-items-center mb-2">
                        <h6 className="fw-bold mb-0">Items ordered</h6>
                        <span className="text-muted small">
                          {order.items.length} {order.items.length === 1 ? 'item' : 'items'}
                        </span>
                      </div>

                      {order.items.map((item, index) => {
                        const productId = item.product?._id || item.product
                        const productName = item.productName || item.product?.name || 'Product'

                        return (
                          <div key={item._id || index}>
                            <div className="order-product">
                              <div>
                                <div className="product-name">
                                  {productName}
                                </div>
                                <div className="product-meta">
                                  Quantity: {item.quantity}
                                </div>
                              </div>

                              <div className="d-flex align-items-center flex-wrap gap-3">
                                <div className="product-price">
                                  ₹{(
                                    Number(item.price || 0) *
                                    Number(item.quantity || 0)
                                  ).toLocaleString('en-IN')}
                                </div>

                                {order.orderStatus === 'Delivered' && productId && (
                                  <button
                                    type="button"
                                    className="btn btn-outline-primary btn-sm"
                                    onClick={() => {
                                      setReviewTarget({
                                        orderId: order._id,
                                        productId: productId.toString(),
                                        productName: productName
                                      })
                                      setRating(5)
                                      setReviewText('')
                                    }}
                                  >
                                    ★ Write Review
                                  </button>
                                )}
                              </div>
                            </div>

                            {reviewTarget?.orderId === order._id &&
                              reviewTarget?.productId === productId?.toString() && (
                                <div className="review-form">
                                  <h5 className="fw-bold mb-2">
                                    Review: {reviewTarget.productName}
                                  </h5>

                                  <p className="text-muted small">
                                    Share your experience with this product.
                                  </p>

                                  <form onSubmit={handleAddReview}>
                                    <label className="form-label">
                                      Your Rating
                                    </label>

                                    <div className="d-flex gap-2 mb-3">
                                      {[1, 2, 3, 4, 5].map((star) => (
                                        <button
                                          type="button"
                                          key={star}
                                          className="review-star"
                                          style={{
                                            color: star <= rating ? '#ffc107' : '#ced4da'
                                          }}
                                          onClick={() => setRating(star)}
                                          aria-label={`${star} star rating`}
                                        >
                                          ★
                                        </button>
                                      ))}
                                    </div>

                                    <label className="form-label">
                                      Your Review
                                    </label>

                                    <textarea
                                      className="form-control mb-3"
                                      rows="3"
                                      maxLength="1000"
                                      placeholder="Share your experience..."
                                      value={reviewText}
                                      onChange={(e) => setReviewText(e.target.value)}
                                      required
                                    />

                                    <button
                                      type="submit"
                                      className="btn btn-primary"
                                      disabled={reviewLoading}
                                    >
                                      {reviewLoading ? 'Submitting...' : 'Submit Review'}
                                    </button>

                                    <button
                                      type="button"
                                      className="btn btn-outline-secondary ms-2"
                                      onClick={() => setReviewTarget(null)}
                                      disabled={reviewLoading}
                                    >
                                      Cancel
                                    </button>
                                  </form>
                                </div>
                              )}
                          </div>
                        )
                      })}

                      {progress >= 0 && (
                        <>
                          <hr className="my-4" />

                          <h6 className="fw-bold mb-1">
                            Delivery progress
                          </h6>
                          <p className="text-muted small">
                            {order.orderStatus === 'Delivered'
                              ? 'Your order has been delivered.'
                              : 'We will update your order as it moves through each stage.'}
                          </p>

                          <div
                            className="order-progress"
                            aria-label={`Order status: ${order.orderStatus}`}
                          >
                            {steps.map((step, index) => (
                              <div
                                key={step}
                                className={`progress-step ${
                                  index <= progress ? 'complete' : ''
                                }`}
                              >
                                <div className="progress-dot">
                                  {index <= progress ? '✓' : index + 1}
                                </div>
                                <div className="progress-label">
                                  {step}
                                </div>
                              </div>
                            ))}
                          </div>
                        </>
                      )}

                      {(order.orderStatus === 'Cancelled' ||
                        order.orderStatus === 'Returned') && (
                        <div className="alert alert-danger mt-3 mb-0">
                          {order.orderStatus === 'Cancelled'
                            ? 'This order has been cancelled.'
                            : 'This order has been returned.'}
                        </div>
                      )}

                      <hr className="my-4" />

                      <div className="order-total-box">
                        <div className="d-flex justify-content-between align-items-center gap-3">
                          <div>
                            <div className="fw-bold">Order total</div>
                            <div className="text-muted small">
                              {order.deliveryCharge !== undefined
                                ? Number(order.deliveryCharge) === 0
                                  ? 'Free delivery included'
                                  : `Delivery: ₹${Number(order.deliveryCharge).toLocaleString('en-IN')}`
                                : 'Including applicable charges'}
                            </div>
                          </div>

                          <div className="order-total">
                            ₹{Number(order.totalAmount || 0).toLocaleString('en-IN')}
                          </div>
                        </div>
                      </div>
                    </div>
                  </article>
                </div>
              )
            })}
          </div>
        )}
      </section>
    </div>
  )
}