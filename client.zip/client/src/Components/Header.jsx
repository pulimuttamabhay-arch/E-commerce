
import React, { useState, useEffect } from 'react'
import { useNavigate, Link } from 'react-router-dom'
import axios from 'axios'

export default function Header() {
  const navigate = useNavigate()

  const [cartcount, setCartcount] = useState(0)

  const [wishlistcount, setWishlistcount] = useState(
    () => (JSON.parse(localStorage.getItem('wishlist')) || []).length
  )

  const updateCartCount = async () => {
    try {
      const token = localStorage.getItem('Usertoken')

      if (!token) {
        setCartcount(0)
        return
      }

      const res = await axios.get(
        'http://localhost:7002/cart/viewcart',
        {
          headers: {
            Authorization: `Bearer ${token}`
          }
        }
      )

      const cart = res.data.items || []

      const totalquantity = cart.reduce(
        (total, item) => total + Number(item.quantity || 0),
        0
      )

      setCartcount(totalquantity)

    } catch (error) {
      console.log(
        'Cart count error:',
        error.response?.data || error.message
      )
    }
  }

  useEffect(() => {
    updateCartCount()

    window.addEventListener('cartUpdated', updateCartCount)
    window.addEventListener('storage', updateCartCount)

    return () => {
      window.removeEventListener('cartUpdated', updateCartCount)
      window.removeEventListener('storage', updateCartCount)
    }
  }, [])

  useEffect(() => {
    const updateWishlistCount = () => {
      const items = JSON.parse(localStorage.getItem('wishlist')) || []
      setWishlistcount(items.length)
    }

    window.addEventListener('wishlistUpdated', updateWishlistCount)
    window.addEventListener('storage', updateWishlistCount)

    return () => {
      window.removeEventListener('wishlistUpdated', updateWishlistCount)
      window.removeEventListener('storage', updateWishlistCount)
    }
  }, [])

  const handlelogout = () => {
    const conformlogout = window.confirm(
      'Are You Sure Want To Logout ?'
    )

    if (conformlogout) {
      localStorage.removeItem('Usertoken')
      setCartcount(0)
      alert('logged Out Successfully !! ')
      navigate('/')
    }
  }

  return (
    <div>
      <header className="navbar navbar-expand-lg sticky-top">
        <div className="container">
          <Link className="navbar-brand" to="/">
            Quick
            <span>Sell</span>
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-target="#nav"
            data-bs-toggle="collapse"
            aria-controls="nav"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            ☰
          </button>

          <div className="collapse navbar-collapse" id="nav">
            <ul className="navbar-nav mx-auto">
              <li>
                <Link className="nav-link" to="/">
                  Home
                </Link>
              </li>

              <li>
                <Link className="nav-link" to="/shop">
                  Shop
                </Link>
              </li>

              <li>
                <Link className="nav-link" to="/category">
                  Categories
                </Link>
              </li>

              <li>
                <Link className="nav-link" to="/about">
                  About
                </Link>
              </li>

              <li>
                <Link className="nav-link" to="/contact">
                  Contact
                </Link>
              </li>

              <li>
                <Link className="nav-link" to="/myorders">
                  My Orders
                </Link>
              </li>
            </ul>

            <div className="d-flex align-items-center">
              <Link className="icon-btn" to="/shop" title="Search products">
                ⌕
              </Link>

              <Link className="icon-btn" to="/login" title="Login">
                ♙
              </Link>

              <button
                type="button"
                className="bi bi-box-arrow-right icon-btn"
                onClick={handlelogout}
                title="Logout"
              />

              <Link
                className="icon-btn position-relative"
                to="/wishlist"
                title="My Wishlist"
              >
                ♡

                {wishlistcount > 0 && (
                  <span className="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                    {wishlistcount}
                  </span>
                )}
              </Link>

              <Link
                className="icon-btn position-relative"
                to="/cart"
                title="Shopping Cart"
              >
                🛒

                <span className="cart-count position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">
                  {cartcount}
                </span>
              </Link>
            </div>
          </div>
        </div>
      </header>
    </div>
  )
}
