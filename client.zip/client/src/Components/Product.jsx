import React, { useState, useEffect } from 'react'
import axios from 'axios'
import { useParams, Link } from 'react-router-dom'

export default function Product() {

    const { pid } = useParams()
    const [product, setProduct] = useState(null)
    const [loading, setLoading] = useState(true)
    const [quantity, setQuantity] = useState(1)
    const [reviews, setReviews] = useState([])
    const [reviewLoading, setReviewLoading] = useState(true)

    const fetchproduct = () => {
        setLoading(true)
        console.log(pid)

        axios.get(`http://localhost:7002/product/getproduct/${pid}`)
            .then((res) => {
                console.log(res)

                setProduct(res.data.singleproduct)
                setQuantity(1)
            })
            .catch((error) => {
                console.log(error.response?.data || error)
                setProduct(null)
            })
            .finally(() => {
                setLoading(false)
            })
    }

    useEffect(() => {
        fetchproduct()
    }, [pid])

    const fetchreviews = () => {
        setReviewLoading(true)

        axios.get(`http://localhost:7002/review/viewreview/${pid}`)
            .then((res) => {
                console.log('Review response:', res.data)

                const reviewData = Array.isArray(res.data)
                    ? res.data
                    : Array.isArray(res.data.reviews)
                        ? res.data.reviews
                        : Array.isArray(res.data.allreviews)
                            ? res.data.allreviews
                            : []

                setReviews(reviewData)
            })
            .catch((error) => {
                console.log('Review fetch error:', error.response?.data || error)
                setReviews([])
            })
            .finally(() => {
                setReviewLoading(false)
            })
    }

    useEffect(() => {
        fetchreviews()
    }, [pid])

    const totalReviews = reviews.length

    const averageRating = totalReviews > 0
        ? reviews.reduce(
            (total, review) => total + Number(review.rating || 0),
            0
        ) / totalReviews
        : 0

    const getRatingCount = (star) => {
        return reviews.filter(
            (review) => Math.round(Number(review.rating) || 0) === star
        ).length
    }

    const getRatingPercentage = (star) => {
        return totalReviews > 0
            ? (getRatingCount(star) / totalReviews) * 100
            : 0
    }

    const handleAddToCart = async () => {
        try {
            const token = localStorage.getItem('Usertoken') ||
                localStorage.getItem('usertoken') ||
                localStorage.getItem('UserToken')

            if (!token) {
                alert('Please login first')
                return
            }

            if (Number(product.stock) < 1) {
                alert('Product is out of stock')
                return
            }

            if (quantity < 1 || quantity > Number(product.stock)) {
                alert('Requested quantity is unavailable')
                return
            }

            const res = await axios.post(
                'http://localhost:7002/cart/addtocart',
                {
                    productId: product._id,
                    quantity: quantity
                },
                {
                    headers: {
                        Authorization: `Bearer ${token}`
                    }
                }
            )

            console.log('Add to cart response:', res.data)

            alert('Product added to cart successfully')

        } catch (error) {
            console.log('Add to cart error:', error.response?.data || error)
            alert(error.response?.data?.message || 'Unable to add product')
        }
    }

    if (loading) {
        return <div className="container section">Loading product...</div>
    }

    if (!product) {
        return (
            <div className="container section">
                <h3>Product not found</h3>
                <Link to="/shop">Back to Shop</Link>
            </div>
        )
    }

    const productImage = Array.isArray(product.image)
        ? product.image[0]
        : product.image

    const productRating = Math.min(5, Math.max(0, Number(product.averageRating) || 0))

    return (
        <div>
            <section className="page-head">
                <div className="container">
                    <div className="eyebrow">
                        QuickSell / Product
                    </div>
                    <h1 className="mb-0">
                        Product Details
                    </h1>
                </div>
            </section>

            <main className="section pt-5">
                <div className="container">
                    <div className="row g-5 align-items-start">

                        {/* PRODUCT IMAGE */}
                        <div className="col-lg-6">
                            <div className="product-detail-gallery">
                                <div className="detail-image-wrap">
                                    <img
                                        src={
                                            productImage
                                                ? `http://localhost:7002/image/${productImage}`
                                                : '/assets/img/product-1.png'
                                        }
                                        className="detail-img"
                                        alt={product.name || 'Product'}
                                        onError={(e) => {
                                            e.currentTarget.onerror = null
                                            e.currentTarget.src = '/assets/img/product-1.png'
                                        }}
                                    />
                                </div>

                                <div className="d-flex gap-2 mt-3">
                                    <span className="badge bg-light text-dark border">
                                        Authentic Product
                                    </span>

                                    <span className="badge bg-light text-dark border">
                                        {Number(product.stock) > 0
                                            ? 'In Stock'
                                            : 'Out of Stock'}
                                    </span>
                                </div>
                            </div>
                        </div>

                        {/* PRODUCT INFORMATION */}
                        <div className="col-lg-6 ps-lg-4">
                            <span className="eyebrow">
                                {product.category?.name || 'Product'}
                            </span>

                            <h1 className="display-font mt-2 mb-3">
                                {product.name}
                            </h1>

                            <div className="d-flex align-items-center gap-3 mb-4">
                                <span className="price detail-price">
                                    ₹{product.price}
                                </span>
                            </div>

                            <div className="rating mb-2">
                                <span className="text-warning">
                                    {'★'.repeat(Math.round(productRating))}
                                    {'☆'.repeat(5 - Math.round(productRating))}
                                </span>

                                <span className="small-muted ms-2">
                                    {productRating.toFixed(1)}
                                </span>

                                <span className="small-muted ms-1">
                                    ({product.totalReviews || 0})
                                </span>
                            </div>

                            <hr className="my-4" />

                            <h5>Product Description</h5>

                            <p className="small-muted">
                                {product.description}
                            </p>

                            <p className="small-muted">
                                <strong>Brand:</strong> {product.brand || 'N/A'}
                            </p>

                            <p className="small-muted">
                                <strong>Available Stock:</strong> {product.stock}
                            </p>

                            {/* QUANTITY */}
                            <div className="d-flex align-items-center gap-3 mt-4 flex-wrap">

                                <div className="quantity-control">
                                    <button
                                        type="button"
                                        onClick={() =>
                                            setQuantity(
                                                Math.max(1, quantity - 1)
                                            )
                                        }
                                        disabled={quantity <= 1}
                                    >
                                        −
                                    </button>

                                    <span>{quantity}</span>

                                    <button
                                        type="button"
                                        onClick={() =>
                                            setQuantity(
                                                Math.min(
                                                    Number(product.stock),
                                                    quantity + 1
                                                )
                                            )
                                        }
                                        disabled={
                                            quantity >= Number(product.stock) ||
                                            Number(product.stock) < 1
                                        }
                                    >
                                        +
                                    </button>
                                </div>

                                <button
                                    type="button"
                                    className="btn btn-brand btn-lg"
                                    onClick={handleAddToCart}
                                    disabled={Number(product.stock) < 1}
                                >
                                    Add to Cart
                                </button>

                                <Link
                                    to="/cart"
                                    className="btn btn-outline-dark btn-lg"
                                >
                                    View Cart
                                </Link>
                            </div>

                            {/* PRODUCT INFORMATION BOXES */}
                            <div className="row g-3 mt-4">

                                <div className="col-sm-6">
                                    <div className="detail-info">
                                        <strong>🚚 Free Delivery</strong>
                                        <small>On orders above ₹999</small>
                                    </div>
                                </div>

                                <div className="col-sm-6">
                                    <div className="detail-info">
                                        <strong>↩ 7-Day Returns</strong>
                                        <small>Easy replacement support</small>
                                    </div>
                                </div>

                                <div className="col-sm-6">
                                    <div className="detail-info">
                                        <strong>🔒 Secure Checkout</strong>
                                        <small>Safe shopping experience</small>
                                    </div>
                                </div>

                                <div className="col-sm-6">
                                    <div className="detail-info">
                                        <strong>✓ Quality Checked</strong>
                                        <small>Selected for QuickSell</small>
                                    </div>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </main>

            {/* CUSTOMER REVIEWS */}
            <section className="section pt-0">
                <div className="container">
                    <div className="row">
                        <div className="col-lg-8">

                            <h2 className="mb-2">Customer Reviews</h2>

                            <p className="small-muted mb-4">
                                See what customers think about this product.
                            </p>

                            {reviewLoading ? (
                                <p className="text-muted">
                                    Loading reviews...
                                </p>
                            ) : (
                                <>
                                    <div className="border rounded-3 p-4 mb-4">
                                        <div className="row align-items-center">

                                            <div className="col-md-4 text-center mb-3 mb-md-0">
                                                <h1 className="mb-1">
                                                    {averageRating.toFixed(1)}/5
                                                </h1>

                                                <div className="text-warning fs-4">
                                                    {'★'.repeat(Math.round(averageRating))}
                                                    {'☆'.repeat(5 - Math.round(averageRating))}
                                                </div>

                                                <p className="small-muted mb-0">
                                                    {totalReviews} {totalReviews === 1 ? 'review' : 'reviews'}
                                                </p>
                                            </div>

                                            <div className="col-md-8">
                                                {[5, 4, 3, 2, 1].map((star) => (
                                                    <div
                                                        className="d-flex align-items-center gap-2 mb-2"
                                                        key={star}
                                                    >
                                                        <span style={{ minWidth: '50px' }}>
                                                            {star} star
                                                        </span>

                                                        <div
                                                            className="progress flex-grow-1"
                                                            style={{
                                                                height: '12px',
                                                                backgroundColor: '#eeeeee'
                                                            }}
                                                        >
                                                            <div
                                                                className="progress-bar bg-warning"
                                                                style={{
                                                                    width: `${getRatingPercentage(star)}%`
                                                                }}
                                                            />
                                                        </div>

                                                        <span
                                                            className="small-muted text-end"
                                                            style={{ minWidth: '55px' }}
                                                        >
                                                            {getRatingCount(star)} {getRatingCount(star) === 1 ? 'user' : 'users'}
                                                        </span>
                                                    </div>
                                                ))}
                                            </div>

                                        </div>
                                    </div>

                                    {reviews.length === 0 ? (
                                        <div className="border rounded-3 p-4">
                                            <h5>No reviews yet</h5>
                                            <p className="small-muted mb-0">
                                                After your order is delivered, you can
                                                share your experience from My Orders.
                                            </p>
                                        </div>
                                    ) : (
                                        reviews.map((review) => (
                                            <div
                                                className="card p-3 mb-3"
                                                key={review._id}
                                            >
                                                <div className="d-flex justify-content-between align-items-start flex-wrap gap-2">
                                                    <div>
                                                        <strong>
                                                            {review.customer?.name || 'Customer'}
                                                        </strong>

                                                        <div className="text-warning mt-1">
                                                            {'★'.repeat(Math.min(5, Math.max(0, Math.round(Number(review.rating) || 0))))}
                                                            {'☆'.repeat(5 - Math.min(5, Math.max(0, Math.round(Number(review.rating) || 0))))}
                                                        </div>
                                                    </div>

                                                    <small className="text-secondary">
                                                        {review.createdAt
                                                            ? new Date(review.createdAt).toLocaleDateString(
                                                                'en-IN',
                                                                {
                                                                    day: 'numeric',
                                                                    month: 'short',
                                                                    year: 'numeric'
                                                                }
                                                            )
                                                            : ''}
                                                    </small>
                                                </div>

                                                <p className="mt-3 mb-0">
                                                    {review.comment || 'No comment provided.'}
                                                </p>
                                            </div>
                                        ))
                                    )}
                                </>
                            )}

                            <div className="border rounded-3 p-4 mt-4">
                                <h5 className="mb-2">Want to review this product?</h5>

                                <p className="small-muted mb-3">
                                    Reviews are available to customers after
                                    their order has been delivered.
                                </p>

                                <Link
                                    to="/myorders"
                                    className="btn btn-brand"
                                >
                                    Go to My Orders
                                </Link>
                            </div>

                        </div>
                    </div>
                </div>
            </section>
        </div>
    )
}