
import React, { useEffect, useState } from 'react'
import axios from 'axios'
import {Link} from 'react-router-dom'

export default function Home() {
    const [wishlist, setWishlist] = useState(
        () => JSON.parse(localStorage.getItem('wishlist')) || []
    )

    const [product, setProduct] = useState([])
    const [category, setCategory] = useState([])

    const fetchcategory = () => {
        axios.get('http://localhost:7002/category/viewcategory')
            .then((res) => {
                console.log(res)
                setCategory(res.data.allcategory)
            })
            .catch((error) => {
                
    console.log(error.response?.data || error.message)
            })
    }

    const fetchedproduct = () => {
        axios.get('http://localhost:7002/product/viewproduct')
            .then((res) => {
                console.log(res)
                setProduct(res.data.allproduct)
            })
            .catch((error) => {
                console.log(error.response?.data || error.message)
            })
    }

    useEffect(() => {
        fetchedproduct()
        fetchcategory()
    }, [])

    useEffect(() => {
        const updateWishlist = () => {
            setWishlist(JSON.parse(localStorage.getItem('wishlist')) || [])
        }

        window.addEventListener('wishlistUpdated', updateWishlist)
        window.addEventListener('storage', updateWishlist)

        return () => {
            window.removeEventListener('wishlistUpdated', updateWishlist)
            window.removeEventListener('storage', updateWishlist)
        }
    }, [])

const addToCart = async (productId) => {
    try {
        const token = localStorage.getItem('Usertoken')

        if (!token) {
            alert('Please login to add products to cart')
            return
        }

        const selectedProduct = product.find(
            (pdata) => pdata._id === productId
        )

        if (!selectedProduct || selectedProduct.stock <= 0) {
            alert('This product is out of stock')
            return
        }

        const res = await axios.post(
            'http://localhost:7002/cart/addtocart',
            {
                productId: productId,
                quantity: 1
            },
            {
                headers: {
                    Authorization: `Bearer ${token}`
                }
            }
        )

        if (res.data.success) {
            alert('Product added to cart')
            window.dispatchEvent(new Event('cartUpdated'))
        }
    } catch (error) {
        alert(
            error.response?.data?.message ||
            'Failed to add product to cart'
        )
    }
}

const toggleWishlist = (productId) => {
    const oldWishlist = JSON.parse(localStorage.getItem('wishlist')) || []

    let newWishlist

    if (oldWishlist.includes(productId)) {
        newWishlist = oldWishlist.filter((id) => id !== productId)
    } else {
        newWishlist = [...oldWishlist, productId]
    }

    localStorage.setItem('wishlist', JSON.stringify(newWishlist))
    setWishlist(newWishlist)

    window.dispatchEvent(new Event('wishlistUpdated'))
}


    return (
        <div>

            {/* HERO SECTION */}
   <section className="hero">
  <div className="container">
    <div className="row align-items-center g-5">

      {/* Text outside the image */}
      <div className="col-lg-6">
        <div className="hero-content">

          <span className="eyebrow">
            New season · smart living
          </span>

          <h1 className="mt-3">
            Everything you need,
            <br />
            all in <span className="nc-highlight">one place.</span>
          </h1>

          <p className="mt-4">
            Explore top-quality cosmetics, tech gadgets and electronic
            essentials at the best prices.
          </p>

          <div className="d-flex gap-2 mt-4 flex-wrap">
            <a className="btn btn-brand" href="/shop">
              Shop collection
            </a>

            <a className="btn btn-outline-dark" href="/category">
              Explore categories
            </a>
          </div>

          <div className="d-flex gap-4 mt-5 small-muted flex-wrap">
            <span>✓ Secure checkout</span>
            <span>✓ Easy returns</span>
            <span>✓ Fast delivery</span>
          </div>

        </div>
      </div>

      {/* Image in a separate outer column */}
      <div className="col-lg-6">
        <div className="hero-image-wrapper">
          <img
            src="/assets/img/novacart-hero-collage.jpg"
            alt="NovaCart electronics collection"
            className="hero-img"
          />
        </div>
      </div>

    </div>
  </div>
</section>

            {/* SHOP BY CATEGORY */}
            <section className="section">
                <div className="container">

                  <div className="d-flex justify-content-between align-items-end mb-4">
    <div>
        <span className="eyebrow">Browse</span>

        <h2 className="section-title mt-2">
            Shop by category
        </h2>
    </div>

    <Link className="fw-bold text-dark" to="/category">
        View all →
    </Link>
</div>

<div className="row g-4">
    {category.map((cdata) => (
        <div className="col-md-6 col-lg-3" key={cdata._id}>
            <Link
                to={`/shop?category=${cdata._id}`}
                className="text-decoration-none"
            >
                <div className="card h-100">
                    <img
                        src={ cdata.image
                            ? `http://localhost:7002/image/${cdata.image}`
                            :'/assets/img/product-1.png'
                        }
                        
                            className="card-img-top"

                        alt={cdata.name}
                    />

                    <div className="card-body">
                        <h5 className="text-dark">
                            {cdata.name}
                        </h5>
                    </div>
                </div>
            </Link>
        </div>
    ))}
</div>
                    {/* <div className="row g-4">

                        {category.map((cdata) => (
                            <div
                                className="col-6 col-lg-3"
                                key={cdata._id}
                            >
                                <a
                                    className="text-decoration-none text-dark"
                                    href="/shop"
                                >
                                    <div className="category-card p-3">

                                        <img
                                            alt={cdata.name}
                                            className="category-img"
                                            src="/assets/img/product-4.png"
                                        />

                                        <h5 className="mt-3">
                                            {cdata.name}
                                        </h5>

                                        <p className="small-muted mb-0">
                                            {cdata.description}
                                        </p>

                                    </div>
                                </a>
                            </div>
                        ))}

                    </div> */}
                </div>
            </section>

            {/* CUSTOMER FAVOURITES */}
           
<section className="section pt-0">
    <div className="container">

        <div className="mb-4">
            <span className="eyebrow">
                Trending now
            </span>

            <h2 className="section-title mt-2">
                Customer favourites
            </h2>
        </div>

        <div className="row g-4" id="featured-grid">

            {product.map((pdata) => (
                <div
                    className="col-md-6 col-lg-3"
                    key={pdata._id}
                >
                    <div className="product-card overflow-hidden">

                        <Link
                            to={`/product/${pdata._id}`}
                            className="product-image-link"
                            aria-label={`View ${pdata.name} details`}
                        >
                            <img
    className="product-img"
    src={
        pdata.image
            ? `http://localhost:7002/image/${pdata.image}`
            : '/assets/img/product-1.png'
    }
    alt={pdata.name}
/>
                        </Link>

                        <div className="product-body">

                            <div className="d-flex justify-content-between align-items-center">

                                <span className="small-muted">
    {
        typeof pdata.category === 'object' && pdata.category !== null
            ? pdata.category.name || 'Uncategorized'
            : category.find(
                (cdata) => cdata._id === pdata.category
            )?.name || 'Uncategorized'
    }
</span>

                                <span className="badge badge-sale">
                                    New
                                </span>

                            </div>

                            <h5 className="mt-2 mb-2">
                                <Link
                                    to={`/product/${pdata._id}`}
                                    className="product-title-link"
                                >
                                    {pdata.name}
                                </Link>
                            </h5>
                            <div className="rating mb-2">
    <span style={{ color: '#ffc107' }}>
        {'★'.repeat(
            Math.min(5, Math.max(0, Math.round(Number(pdata.averageRating) || 0)))
        )}
        {'☆'.repeat(
            5 - Math.min(5, Math.max(0, Math.round(Number(pdata.averageRating) || 0)))
        )}
    </span>

    <span className="small-muted ms-2">
        {Number(pdata.averageRating || 0).toFixed(1)}
    </span>

    <span className="small-muted ms-1">
        ({pdata.totalReviews || 0})
    </span>
</div>
                            

                            <div className="d-flex justify-content-between align-items-center mb-3">
                                <span className="price">
                                    ₹{pdata.price}
                                </span>

                                {pdata.stock <= 0 ? (
                                    <span className="text-danger small fw-bold">
                                        Out of Stock
                                    </span>
                                ) : (
                                    <span className="text-success small">
                                        In Stock
                                    </span>
                                )}
                            </div>

                            <div className="d-flex align-items-center gap-2">

                                {/* Add to Cart */}
                                <button
                                    type="button"
                                    className="icon-btn"
                                    title={
                                        pdata.stock <= 0
                                            ? 'Out of Stock'
                                            : 'Add to cart'
                                    }
                                    disabled={pdata.stock <= 0}
                                    onClick={() => addToCart(pdata._id)}
                                >
                                    +
                                </button>

                                {/* Wishlist */}
                                <button
                                    type="button"
                                    className="icon-btn"
                                    title={
                                        wishlist.includes(pdata._id)
                                            ? 'Remove from wishlist'
                                            : 'Add to wishlist'
                                    }
                                    onClick={() => toggleWishlist(pdata._id)}
                                    style={{
                                        color: wishlist.includes(pdata._id)
                                            ? '#e63946'
                                            : 'inherit',
                                        border: '1px solid #ddd',
                                        background: 'white'
                                    }}
                                >
                                    {wishlist.includes(pdata._id)
                                        ? '♥'
                                        : '♡'}
                                </button>

                                <Link
                                    to={`/product/${pdata._id}`}
                                    className="btn btn-outline-dark btn-sm ms-auto"
                                >
                                    View product
                                </Link>

                            </div>

                        </div>
                    </div>
                </div>
            ))}

        </div>
    </div>
</section>


            {/* BANNER SECTION */}
            <section className="section pt-0">
                <div className="container">

                    <div className="banner">
                        <div className="row align-items-center">

                            <div className="col-lg-8">
                                <span className="eyebrow text-white">
                                    For creators &amp; gamers
                                </span>

                                <h2 className="display-font mt-2">
                                    Upgrade your setup without overcomplicating it.
                                </h2>

                                <p>
                                    Shop practical gear for work, play and everything between.
                                </p>
                            </div>

                            <div className="col-lg-4 text-lg-end">
                                <a className="btn btn-light" href="/shop">
                                    Shop gaming &amp; tech
                                </a>
                            </div>

                        </div>
                    </div>
                </div>
            </section>

        </div>
    )
}
