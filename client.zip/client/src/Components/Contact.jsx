
import React, { useState } from "react";

export default function Contact() {
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    subject: "",
    message: "",
  });

  const [status, setStatus] = useState({
    loading: false,
    message: "",
    type: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;

    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    setStatus({
      loading: true,
      message: "",
      type: "",
    });

    try {
      const response = await fetch(
        `${import.meta.env.VITE_API_URL || "http://localhost:7002"}/api/contact`,
        {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(formData),
        }
      );

      const data = await response.json();

      if (!response.ok || !data.success) {
        throw new Error(data.message || "Failed to submit message.");
      }

      setFormData({
        name: "",
        email: "",
        subject: "",
        message: "",
      });

      setStatus({
        loading: false,
        message: data.message,
        type: data.emailSent === false ? "warning" : "success",
      });
    } catch (error) {
      setStatus({
        loading: false,
        message:
          error.message ||
          "Unable to send your message. Please try again.",
        type: "error",
      });
    }
  };

  return (
    <>
      <section className="page-head">
        <div className="container">
          <span className="eyebrow">Support</span>
          <h1 className="mt-2">How can we help?</h1>
          <p className="small-muted">
            Send us a message and our team will get back to you.
          </p>
        </div>
      </section>

      <section className="section">
        <div className="container">
          <div className="row g-5">
            <div className="col-lg-7">
              <div className="info-card p-4 p-lg-5">
                <form onSubmit={handleSubmit}>
                  <div className="row g-3">
                    <div className="col-md-6">
                      <label htmlFor="name" className="form-label">
                        Name
                      </label>
                      <input
                        id="name"
                        name="name"
                        className="form-control"
                        placeholder="Your name"
                        value={formData.name}
                        onChange={handleChange}
                        maxLength={100}
                        autoComplete="name"
                        required
                      />
                    </div>

                    <div className="col-md-6">
                      <label htmlFor="email" className="form-label">
                        Email
                      </label>
                      <input
                        id="email"
                        name="email"
                        type="email"
                        className="form-control"
                        placeholder="you@example.com"
                        value={formData.email}
                        onChange={handleChange}
                        maxLength={254}
                        autoComplete="email"
                        required
                      />
                    </div>

                    <div className="col-12">
                      <label htmlFor="subject" className="form-label">
                        Subject
                      </label>
                      <input
                        id="subject"
                        name="subject"
                        className="form-control"
                        placeholder="How can we help?"
                        value={formData.subject}
                        onChange={handleChange}
                        maxLength={200}
                        required
                      />
                    </div>

                    <div className="col-12">
                      <label htmlFor="message" className="form-label">
                        Message
                      </label>
                      <textarea
                        id="message"
                        name="message"
                        className="form-control"
                        placeholder="Write your message..."
                        rows={6}
                        value={formData.message}
                        onChange={handleChange}
                        maxLength={5000}
                        required
                      />
                    </div>

                    <div className="col-12">
                      <button
                        type="submit"
                        className="btn btn-brand"
                        disabled={status.loading}
                      >
                        {status.loading
                          ? "Sending..."
                          : "Send message"}
                      </button>
                    </div>

                    {status.message && (
                      <div className="col-12" role="status" aria-live="polite">
                        <p
                          className={
                            status.type === "success"
                              ? "text-success"
                              : status.type === "warning"
                              ? "text-warning"
                              : "text-danger"
                          }
                        >
                          {status.message}
                        </p>
                      </div>
                    )}
                  </div>
                </form>
              </div>
            </div>

            <div className="col-lg-5">
              <h3>Customer support</h3>
              <p className="small-muted">
                Mon–Sat · 9:00 AM–6:00 PM
              </p>

              <div className="info-card p-4 mt-4">
                <b>Email</b>
                <p className="small-muted mb-0">
                  support@novacart.example
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
    </>
  );
}
