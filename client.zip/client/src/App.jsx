import React from 'react'
import Home from './Components/Home'
import 'bootstrap-icons/font/bootstrap-icons.css'
import { BrowserRouter ,Routes , Route} from 'react-router-dom'
import Header from './Components/Header'
import Footer from './Components/Footer'
import Shop from './Components/Shop'
import Category from './Components/Category'
import Checkout from './Components/Checkout'
import Cart from './Components/Cart'
import Contact from './Components/Contact'
import About from './Components/About'
import Register from './Components/Register'
import Product from './Components/Product'
import Login from './Components/Login'
import MyOrders from './Components/MyOrder'
import Wishlist from './Components/Whishlist'
import DemoPayment from './Components/DemoPayment'
export default function App() {
  return (
    <div>
      <BrowserRouter>
      <Header/>
      <Routes>
        <Route path='/' element={<Home/>}/>
        <Route path='/shop' element={<Shop/>}/>
        <Route path='/category' element={<Category/>}/>
        <Route path='/checkout' element={<Checkout/>}/>
        <Route path='/cart' element={<Cart/>}/>
        <Route path='/contact' element={<Contact/>}/>
        <Route path='/about' element={<About/>}/>
        <Route path='/login' element={<Login/>}/>
        <Route path='/register' element={<Register/>}/>
        <Route path='/product/:pid' element={<Product/>}/>
        <Route path='/myorders' element={<MyOrders/>}/>
        <Route path='/wishlist' element={<Wishlist/>}/>
        <Route path='/demopayment' element={<DemoPayment/>}/>
      </Routes>
      <Footer/>


      </BrowserRouter>
    </div>
  )
}
